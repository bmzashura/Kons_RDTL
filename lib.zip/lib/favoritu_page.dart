import 'package:flutter/material.dart';

class Favoritu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: new Center(
        child: new Column(
          children: <Widget>[
            new Text('Favoritu', style: new TextStyle(fontSize: 20.0),),
          ],
        ),
      ),
    );
  }
}