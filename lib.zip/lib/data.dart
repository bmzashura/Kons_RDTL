class ListArtigu {
  String artigu,
      parte,
      titulu,
      kapitulu,
      subtitulu,
      paragraf;


  
  ListArtigu(
      this.artigu, this.parte, this.titulu, this.kapitulu,this.subtitulu, this.paragraf );
}


final List<ListArtigu>lArtigu = [
  ListArtigu('Artigu 1','PARTE I', '', '', 'A República', '1. A República Democrática de Timor-Leste é um Estado de direito democrático,soberano, independente e unitário, baseado na vontade popular e no respeito pela dignidade da pessoa humana.\n\n2. O dia 28 de Novembro de 1975 é o dia da Proclamação da Independência da República Democrática de Timor-Leste.'),
  ListArtigu('Artigu 2','PARTE I', '', '', 'Soberania e constitucionalidade', '1. A soberania reside no povo, que a exerce nos termos da Constituição./n2. O Estado subordina-se à Constituição e às leis./n3. As leis e os demais actos do Estado e do poder local só são válidos se forem conformes com a Constituição./n4. O Estado reconhece e valoriza as normas e os usos costumeiros de Timor-Leste que não contrariem a Constituição e a legislação que trate especialmente do direito costumeiro.'),
];


